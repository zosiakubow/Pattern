package Pattern;


import javax.swing.*;

public class Window extends JFrame {

    public Window() {
        setTitle("Login_06.2023");
        setSize(500,500);
        setLocation(400, 200);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setVisible(true);


    }

}
