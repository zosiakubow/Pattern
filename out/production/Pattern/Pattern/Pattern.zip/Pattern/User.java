package Pattern;

public class User {
    public String name;
    public String surname;
    public String login;
    public String password;



}
