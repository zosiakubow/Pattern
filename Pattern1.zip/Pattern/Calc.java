package Pattern;

public class Calc {

    public static void main(String[] args) {
        int age = 16;
        String gender = "male";
        double height = 165;
        int weight;

        System.out.println("age = "+ age);
    }
}
