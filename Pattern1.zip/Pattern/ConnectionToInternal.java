package Pattern;

public class ConnectionToInternal {
    public final String url="jdbc:mysql://127.0.0.1:3306/zosiainternal?serverTimezone=UTC";
    public final String user="root";
    public final String pwd="root";
}
